package com.geoghraphy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private data class Lesson(val area: String, val title: String, val summary: String, val detail: String)

private val lessons = listOf(
    Lesson("الجغرافيا الطبيعية", "الموقع الفلكي والجغرافي", "مفاهيم الموقع وخطوط الطول ودوائر العرض",
        "الموقع الفلكي هو تحديد مكان باستخدام خطوط الطول ودوائر العرض. أما الموقع الجغرافي فيصف موضع المكان بالنسبة إلى اليابس والماء والدول والظواهر المحيطة. يُستخدم الموقع في تفسير المناخ والتوزيع السكاني والأنشطة الاقتصادية."),
    Lesson("الجغرافيا الطبيعية", "عناصر المناخ", "الحرارة والضغط والرياح والرطوبة والأمطار",
        "تشمل عناصر المناخ: درجة الحرارة، والضغط الجوي، والرياح، والرطوبة، والتساقط. وتتأثر هذه العناصر بالموقع الفلكي والارتفاع والقرب من البحار والتضاريس والكتل الهوائية."),
    Lesson("الجغرافيا الطبيعية", "أشكال سطح الأرض", "الجبال والهضاب والسهول والأودية",
        "تتكون أشكال سطح الأرض بفعل العمليات الباطنية مثل الالتواءات والانكسارات والبراكين، والعمليات الخارجية مثل التجوية والتعرية والنقل والترسيب. وتؤثر التضاريس في النقل والزراعة والاستقرار البشري."),
    Lesson("الجغرافيا البشرية", "جغرافية السكان", "التوزيع والكثافة والنمو السكاني",
        "تدرس جغرافية السكان توزيع السكان وكثافتهم وتركيبهم ونموهم وحركتهم. ومن مقاييسها الكثافة العامة = عدد السكان ÷ المساحة الكلية. ويجب تفسير التباين المكاني بالعوامل الطبيعية والاقتصادية والاجتماعية."),
    Lesson("الجغرافيا البشرية", "الهجرة", "أنواع الهجرة وأسبابها ونتائجها",
        "الهجرة انتقال الأفراد من مكان إلى آخر بقصد الإقامة المؤقتة أو الدائمة. ومن أسبابها عوامل الطرد مثل البطالة والجفاف، وعوامل الجذب مثل فرص العمل والخدمات. ولها آثار ديموغرافية واقتصادية واجتماعية."),
    Lesson("الجغرافيا البشرية", "جغرافية المدن", "النشأة والنمو والوظائف الحضرية",
        "تهتم جغرافية المدن بمواقع المدن ومواضعها ونموها ووظائفها وشكلها الداخلي وعلاقاتها الإقليمية. وتُدرس مشكلات مثل التوسع العمراني والازدحام واستخدامات الأرض."),
    Lesson("الخرائط والأطلس", "مقياس الرسم", "العلاقة بين المسافة على الخريطة والمسافة على الطبيعة",
        "مقياس الرسم هو النسبة بين مسافة على الخريطة والمسافة المناظرة لها على الطبيعة. إذا كان المقياس 1:100000 فهذا يعني أن 1 سم على الخريطة يقابل 100000 سم على الطبيعة، أي كيلومترًا واحدًا."),
    Lesson("الخرائط والأطلس", "الإحداثيات الجغرافية", "خطوط الطول ودوائر العرض",
        "دوائر العرض دوائر وهمية متوازية تُقاس شمال خط الاستواء وجنوبه، وخطوط الطول أنصاف دوائر تصل بين القطبين وتُقاس شرق خط جرينتش وغربه. ويُستخدم تقاطعهما لتحديد المواقع."),
    Lesson("نظم المعلومات الجغرافية GIS", "مفهوم GIS", "جمع البيانات المكانية وإدارتها وتحليلها وعرضها",
        "نظم المعلومات الجغرافية إطار حاسوبي للتعامل مع البيانات المرتبطة بمواقع على سطح الأرض، ويشمل إدخال البيانات وتخزينها وإدارتها وتحليلها وإخراجها في صورة خرائط وتقارير."),
    Lesson("نظم المعلومات الجغرافية GIS", "البيانات المكانية", "البيانات المتجهة والبيانات raster",
        "البيانات المتجهة Vector تمثل المعالم بنقاط وخطوط ومضلعات، مثل مواقع المدارس والطرق وحدود المحافظات. أما Raster فتمثل الظواهر في خلايا أو بكسلات، مثل صور الأقمار الصناعية ونماذج الارتفاعات."),
    Lesson("نظم المعلومات الجغرافية GIS", "التحليل المكاني", "التراكب والحرم المكاني والاستعلام",
        "من أدوات التحليل المكاني: Buffer لإنشاء نطاق حول المعالم، وOverlay لتراكب الطبقات، وSpatial Query للاستعلام المكاني، وتحليل الكثافة لتوضيح تركز الظواهر. يجب التأكد من نظام الإحداثيات وجودة البيانات قبل التحليل.")
)

private val categories = listOf(
    "الجغرافيا الطبيعية", "الجغرافيا البشرية", "الخرائط والأطلس", "نظم المعلومات الجغرافية GIS"
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                GeoghraphyTheme { GeographyApp() }
            }
        }
    }
}

@Composable
private fun GeoghraphyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1F6B57),
            secondary = Color(0xFFB68B4A),
            background = Color(0xFFF5F7F4),
            surface = Color.White
        ),
        content = content
    )
}

@Composable
private fun GeographyApp() {
    var currentTab by remember { mutableStateOf("home") }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var selectedLesson by remember { mutableStateOf<Lesson?>(null) }
    var search by remember { mutableStateOf("") }

    Scaffold(
        bottomBar = {
            NavigationBar {
                NavigationBarItem(currentTab == "home", { currentTab = "home"; selectedCategory = null; selectedLesson = null },
                    icon = { Icon(Icons.Default.Home, null) }, label = { Text("الرئيسية") })
                NavigationBarItem(currentTab == "library", { currentTab = "library"; selectedCategory = null; selectedLesson = null },
                    icon = { Icon(Icons.Default.MenuBook, null) }, label = { Text("المكتبة") })
                NavigationBarItem(currentTab == "gis", { currentTab = "gis"; selectedCategory = "نظم المعلومات الجغرافية GIS"; selectedLesson = null },
                    icon = { Icon(Icons.Default.Map, null) }, label = { Text("GIS") })
                NavigationBarItem(currentTab == "quiz", { currentTab = "quiz"; selectedCategory = null; selectedLesson = null },
                    icon = { Icon(Icons.Default.Quiz, null) }, label = { Text("اختبار") })
            }
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            when {
                currentTab == "quiz" -> QuizScreen()
                selectedLesson != null -> {
                    TextButton(onClick = { selectedLesson = null }) { Text("→ رجوع للدروس") }
                    Text(selectedLesson!!.area, color = MaterialTheme.colorScheme.primary)
                    Text(selectedLesson!!.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(selectedLesson!!.summary, color = MaterialTheme.colorScheme.secondary)
                    Card { Text(selectedLesson!!.detail, Modifier.padding(18.dp), style = MaterialTheme.typography.bodyLarge) }
                    Text("ملاحظة دراسية: راجع التعريفات والأمثلة، ثم حاول تطبيق المفهوم على خريطة أو حالة جغرافية واقعية.",
                        style = MaterialTheme.typography.bodyMedium)
                }
                selectedCategory != null -> {
                    TextButton(onClick = { selectedCategory = null; currentTab = "library" }) { Text("→ جميع الأقسام") }
                    Text(selectedCategory!!, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    lessons.filter { it.area == selectedCategory }.forEach { lesson ->
                        Card(onClick = { selectedLesson = lesson }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp)) {
                                Text(lesson.title, fontWeight = FontWeight.Bold)
                                Text(lesson.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
                currentTab == "library" -> {
                    Text("المكتبة الجغرافية", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    OutlinedTextField(search, { search = it }, modifier = Modifier.fillMaxWidth(),
                        label = { Text("ابحث عن درس أو مصطلح") }, leadingIcon = { Icon(Icons.Default.Search, null) })
                    val filtered = lessons.filter { it.title.contains(search, true) || it.summary.contains(search, true) || it.area.contains(search, true) }
                    filtered.forEach { lesson ->
                        Card(onClick = { selectedLesson = lesson }, modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Text(lesson.title, fontWeight = FontWeight.Bold)
                                Text(lesson.area, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Text(lesson.summary, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                    if (filtered.isEmpty()) Text("لا توجد نتائج مطابقة.")
                }
                else -> {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("جغرافي 🌍", style = MaterialTheme.typography.headlineMedium, color = Color.White, fontWeight = FontWeight.Bold)
                            Text("دليلك الجامعي لفهم الأرض وتحليل المكان", color = Color.White)
                            Text("محتوى أساسي محفوظ داخل التطبيق ويمكن فتحه دون إنترنت.", color = Color.White)
                        }
                    }
                    Text("أقسام التعلم", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    categories.forEach { category ->
                        Card(onClick = { selectedCategory = category; currentTab = "library" }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Public, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(12.dp))
                                Text(category, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                                Icon(Icons.Default.ChevronLeft, null)
                            }
                        }
                    }
                    Card(onClick = { currentTab = "quiz" }, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Quiz, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Text("اختبر معلوماتك", fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("الاتصال بالإنترنت سيُستخدم لاحقًا لتحديث الدروس والخرائط والمساعد الذكي. النسخة الحالية تقدم مكتبة واختبارًا محليين.")
                }
            }
        }
    }
}

@Composable
private fun QuizScreen() {
    var questionIndex by remember { mutableIntStateOf(0) }
    var answer by remember { mutableIntStateOf(-1) }
    var submitted by remember { mutableStateOf(false) }
    val questions = listOf(
        Triple("ما المقصود بنظم المعلومات الجغرافية GIS؟",
            listOf("نظام لإدارة وتحليل وعرض البيانات المرتبطة بالمواقع", "برنامج لمعالجة النصوص", "جهاز لقياس الحرارة"), 0),
        Triple("ماذا يمثل مقياس الرسم 1:100000؟",
            listOf("1 سم يقابل 100 متر", "1 سم يقابل 1 كم", "1 سم يقابل 10 كم"), 1),
        Triple("أي مما يلي مثال على بيانات Raster؟",
            listOf("حدود محافظة كمضلع", "مسار طريق كخط", "صورة قمر صناعي"), 2)
    )
    val q = questions[questionIndex]
    Text("اختبر معلوماتك", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
    Text("السؤال ${questionIndex + 1} من ${questions.size}", color = MaterialTheme.colorScheme.secondary)
    Text(q.first, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    q.second.forEachIndexed { index, option ->
        Card(onClick = { answer = index; submitted = false }, modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = if (answer == index) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)) {
            Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                RadioButton(answer == index, { answer = index; submitted = false })
                Text(option)
            }
        }
    }
    Button(onClick = { submitted = true }, enabled = answer >= 0) { Text("تصحيح الإجابة") }
    if (submitted) {
        Text(if (answer == q.third) "إجابة صحيحة! أحسنت 👏" else "إجابة غير صحيحة. حاول مراجعة الدرس.",
            color = if (answer == q.third) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            fontWeight = FontWeight.Bold)
        Button(onClick = { questionIndex = (questionIndex + 1) % questions.size; answer = -1; submitted = false }) {
            Text(if (questionIndex == questions.lastIndex) "إعادة الاختبار" else "السؤال التالي")
        }
    }
}
